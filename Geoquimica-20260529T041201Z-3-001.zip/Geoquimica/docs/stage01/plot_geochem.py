"""
Modelación Geoquímica – Formaciones Colombianas
Visualización de resultados PHREEQC (Stage 01)

Formaciones: La Luna · Mugrosa · Rosablanca · Tablazo
Fuentes:
  - Solution.pqi.out   → Escenario Base (agua cruda, especiación inicial)
  - FmSolution.pqi.out → Escenario Reaccionado (equilibrio agua-roca)

Genera tres figuras:
  1. Diagrama de Schoeller (semi-log) – todas las formaciones
  2. Gráfico de dispersión 1:1 – La Luna inicial vs. equilibrio
  3. Gráfico de barras agrupadas – SI Calcita inicial vs. equilibrio

Uso:
    python plot_geochem.py
"""

from pathlib import Path

import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np

# ── Directorio de salida ──────────────────────────────────────────────────────
OUT_DIR = Path(__file__).parent / "figures"
OUT_DIR.mkdir(exist_ok=True)

# ── Estilo global ─────────────────────────────────────────────────────────────
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.25,
        "grid.linestyle": "--",
        "figure.dpi": 130,
        "savefig.dpi": 200,
    }
)
SAVEFIG_KW = {"bbox_inches": "tight"}

PALETTE = {
    "La Luna":    "#1f77b4",   # azul
    "Mugrosa":    "#ff7f0e",   # naranja
    "Rosablanca": "#2ca02c",   # verde
    "Tablazo":    "#9467bd",   # morado
}

# ═══════════════════════════════════════════════════════════════════════════════
# DATOS
# ═══════════════════════════════════════════════════════════════════════════════

# Iones para diagrama de Schoeller
IONS = ["Na", "K", "Ca", "Mg", "Cl", "SO₄", "HCO₃"]

# ── Agua cruda inicial (mg/L) ─────────────────────────────────────────────────
# Fuente: Solution.pqi.out y FmSolution.pqi.out (initial solutions)
# Rosablanca y Tablazo comparten la misma analítica (Tablazo_y_Rosablanca)
INITIAL: dict[str, list[float]] = {
    # fmt: off
    #            Na        K       Ca       Mg       Cl       SO4    HCO3
    "La Luna":    [23845.0, 2410.0,   105.0,   62.0,  38510.0,  185.0, 3357.5],
    "Mugrosa":    [16398.9,   71.4,  3401.8,  202.0,  20122.9,   19.5,  127.6],
    "Rosablanca": [21840.0, 3804.7, 10685.2, 1090.0,  56264.8,  233.8,  747.2],
    "Tablazo":    [21840.0, 3804.7, 10685.2, 1090.0,  56264.8,  233.8,  747.2],
    # fmt: on
}

# ── Agua equilibrada – todas las formaciones (mg/L) ─────────────────────────
# Fuente: FmSolution_v2.out (simulaciones independientes separadas por END)
# Conversión: mg/L = molalidad (mol/kgw) × PM (g/mol) × (kgw/L) × 1000
#   kgw/L = masa_agua_kgw / volumen_solución_L  (tomados del bloque Description)
#
# La Luna  (kgw/L = 0.08223/0.08425 = 0.9760):
#   Na=1.0381×22990×0.976=23304 | K=0.07997×39100×0.976=3051
#   Ca=1.837e-5×40080×0.976=0.72 | Mg=1.035e-5×24310×0.976=0.25
#   Cl=1.0872×35450×0.976=37617 | SO4=1.928e-3×96060×0.976=180.9
#   HCO3=Alk(6.307e-2 eq/kgw)×61020×0.976=3757
# Mugrosa  (kgw/L = 0.1630/0.16504 = 0.9876):
#   Na=0.72395×22990×0.9876=16426 | K=5.489e-4×39100×0.9876=21.2
#   Ca=8.367e-2×40080×0.9876=3313 | Mg=1.074e-2×24310×0.9876=258
#   Cl=0.57606×35450×0.9876=20162 | SO4=2.060e-4×96060×0.9876=19.6
#   HCO3=Alk(4.575e-4)×61020×0.9876=27.6
# Rosablanca / Tablazo  (kgw/L = 0.9711):
#   Na=0.95063×22990×0.9711=21230 | K=9.737e-2×39100×0.9711=3694
#   Ca=2.643e-1×40080×0.9711=10286 | Mg=4.486e-2×24310×0.9711=1059
#   Cl=1.5881×35450×0.9711=54668 | SO4=2.436e-3×96060×0.9711=227
#   HCO3=Alk(7.294e-3)×61020×0.9711=432
EQUILIBRIUM: dict[str, list[float]] = {
    # fmt: off
    #              Na        K       Ca       Mg       Cl       SO4    HCO3
    "La Luna":    [23304.0, 3051.0,  0.72,   0.25,  37617.0,  180.9, 3757.0],
    "Mugrosa":    [16426.0,   21.2, 3313.0, 258.0,  20162.0,   19.6,   27.6],
    "Rosablanca": [21230.0, 3694.0, 10286.0, 1059.0, 54668.0, 227.0,  432.0],
    "Tablazo":    [21230.0, 3694.0, 10286.0, 1059.0, 54668.0, 227.0,  432.0],
    # fmt: on
}

# Alias para compatibilidad con código existente (Fig 2)
LA_LUNA_EQ: list[float] = EQUILIBRIUM["La Luna"]

# ── pH ────────────────────────────────────────────────────────────────────────
# Fuente: Solution.pqi.out (inicial) y FmSolution_v2.out (equilibrio)
PH_INITIAL = {
    "La Luna":    7.90,
    "Mugrosa":    6.60,
    "Rosablanca": 6.10,
    "Tablazo":    6.10,
}
PH_EQ = {
    "La Luna":    9.339,   # pH aumenta por buffer silicato-carbonato
    "Mugrosa":    9.791,   # pH aumenta – disolución K-feldespato + Illita
    "Rosablanca": 5.672,   # pH baja – disolución Pirita produce H+
    "Tablazo":    5.672,   # ídem Rosablanca (mineralogía y química idénticas)
}
PH_EQ_LA_LUNA = PH_EQ["La Luna"]  # retrocompatibilidad

# ── Índice de Saturación – Calcita ────────────────────────────────────────────
# Fuente: FmSolution_v2.out / FmSolution_v2_*.sel (simulaciones independientes)
# Valores exactos del .sel: La Luna=1.2244, Mugrosa=0.0542, Rosablanca=Tablazo=0.6532
# Equilibrio: SI_Calcite = 0.00 confirmado en todos los Phase assemblage blocks
SI_CALCITE = {
    "La Luna":    {"inicial": 1.2244, "equilibrio": 0.00},
    "Mugrosa":    {"inicial": 0.0542, "equilibrio": 0.00},
    "Rosablanca": {"inicial": 0.6532, "equilibrio": 0.00},
    "Tablazo":    {"inicial": 0.6532, "equilibrio": 0.00},
}

# ── Transferencia de masa mineral – La Luna (Δ moles totales) ─────────────────
# Fuente: FmSolution.pqi.out Phase assemblage, Reaction step 1
# Δ = Final − Inicial  →  (+) precipitación  |  (−) disolución
PHASES_DELTA = {
    "Calcita":   -6.213e-4,
    "Dolomita":  +8.354e-4,
    "Illita":    -2.505e-3,
    "Caolinita": +2.881e-3,
    "Cuarzo":    +2.997e-3,
}


# ═══════════════════════════════════════════════════════════════════════════════
# FIGURA 1 – DIAGRAMA DE SCHOELLER
# ═══════════════════════════════════════════════════════════════════════════════
def plot_schoeller() -> None:
    """
    Diagrama semi-logarítmico (Schoeller) comparando la concentración de iones
    mayores en las cuatro formaciones (agua cruda) más el agua de La Luna
    tras equilibrio agua-roca.
    """
    fig, ax = plt.subplots(figsize=(10, 5.8))

    x = np.arange(len(IONS))
    markers = {"La Luna": "o", "Mugrosa": "s", "Rosablanca": "^", "Tablazo": "D"}

    # Aguas crudas iniciales
    for fm, vals in INITIAL.items():
        ax.semilogy(
            x,
            vals,
            linestyle="-",
            marker=markers[fm],
            color=PALETTE[fm],
            linewidth=1.9,
            markersize=7,
            label=f"{fm} (inicial)",
            zorder=3,
        )

    # Líneas de equilibrio agua-roca (discontinuas, mismo color por formación)
    for fm, eq_vals in EQUILIBRIUM.items():
        ax.semilogy(
            x,
            eq_vals,
            linestyle="--",
            marker=markers[fm],
            color=PALETTE[fm],
            linewidth=2.0,
            markersize=6,
            alpha=0.70,
            label=f"{fm} (equilibrio)",
            zorder=4,
        )

    # Flechas en Ca y Mg donde el cambio es más pronunciado (La Luna y Mugrosa)
    for fm in ("La Luna", "Mugrosa"):
        for idx, (ini, eq) in enumerate(zip(INITIAL[fm], EQUILIBRIUM[fm])):
            if IONS[idx] in ("Ca", "Mg") and abs(ini - eq) / max(ini, eq) > 0.3:
                ax.annotate(
                    "",
                    xy=(idx, eq),
                    xytext=(idx, ini),
                    arrowprops=dict(
                        arrowstyle="-|>",
                        color=PALETTE[fm],
                        lw=1.3,
                        alpha=0.55,
                    ),
                )

    ax.set_xticks(x)
    ax.set_xticklabels(IONS, fontsize=12)
    ax.set_ylabel("Concentración (mg/L)", fontsize=12)
    ax.set_title(
        "Diagrama de Schoeller – Aguas de Formación\n"
        "Escenario Base vs. Equilibrio Agua-Roca",
        fontsize=12,
        pad=10,
    )
    ax.set_ylim(0.08, 2e5)
    ax.legend(fontsize=8.5, loc="lower right", framealpha=0.9, ncol=2)

    # Anotación de pH (inicial → equilibrio)
    ph_lines = []
    for fm in ("La Luna", "Mugrosa", "Rosablanca", "Tablazo"):
        ph_lines.append(f"{fm}: pH {PH_INITIAL[fm]:.1f} → {PH_EQ[fm]:.2f}")
    ph_text = "pH  inicial → equilibrio\n" + " | ".join(ph_lines[:2]) + "\n" + " | ".join(ph_lines[2:])
    ax.text(
        0.01, 0.03, ph_text,
        transform=ax.transAxes,
        fontsize=7.5,
        color="dimgray",
        va="bottom",
        style="italic",
    )

    fig.tight_layout()
    path = OUT_DIR / "fig1_schoeller.png"
    fig.savefig(path, **SAVEFIG_KW)
    print(f"  ✓ {path}")
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════════
# FIGURA 2 – GRÁFICO 1:1 (La Luna inicial vs. equilibrio)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_scatter_1to1() -> None:
    """
    Gráfico de dispersión log-log que compara la concentración de iones de
    La Luna antes (eje X) y después (eje Y) de la reacción agua-roca.

    Puntos SOBRE la línea 1:1 → enriquecimiento (ion entró desde la roca)
    Puntos BAJO  la línea 1:1 → empobrecimiento (ion salió hacia la roca)
    """
    ini = np.array(INITIAL["La Luna"])
    eq = np.array(LA_LUNA_EQ)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5.5),
                              gridspec_kw={"width_ratios": [1.4, 1]})

    # ── Panel izquierdo: scatter 1:1 ─────────────────────────────────────────
    ax = axes[0]

    all_vals = np.concatenate([ini, eq])
    lim_lo = 10 ** (np.floor(np.log10(all_vals.min())) - 0.5)
    lim_hi = 10 ** (np.ceil(np.log10(all_vals.max())) + 0.3)
    lims = [lim_lo, lim_hi]

    # Línea 1:1
    ax.loglog(lims, lims, "k--", linewidth=1.5, alpha=0.55,
              label="Línea 1:1 (sin cambio)")

    # Bandas de factor ×2 / ×0.5
    ax.fill_between(lims, [v * 0.5 for v in lims], [v * 2.0 for v in lims],
                    color="gray", alpha=0.06)

    # Puntos
    OFFSETS = {
        "Na":  (1.15,  1.20),
        "K":   (0.75,  1.25),
        "Ca":  (1.15,  0.55),
        "Mg":  (0.55,  0.55),
        "Cl":  (1.15,  0.80),
        "SO₄": (1.15,  1.25),
        "HCO₃":(0.65,  1.30),
    }

    for ion, c_i, c_f in zip(IONS, ini, eq):
        enrich = c_f >= c_i
        color = "#2ca02c" if enrich else "#d62728"
        ax.scatter(c_i, c_f, s=110, color=color, zorder=5, edgecolors="white",
                   linewidths=0.8)
        ox, oy = OFFSETS.get(ion, (1.2, 1.1))
        ax.annotate(
            ion,
            xy=(c_i, c_f),
            xytext=(c_i * ox, c_f * oy),
            fontsize=9.5,
            fontweight="bold",
            color=color,
            arrowprops=dict(arrowstyle="-", color="lightgray", lw=0.7),
        )

    ax.set_xlim(lims)
    ax.set_ylim(lims)
    ax.set_xlabel("Concentración Inicial (mg/L)", fontsize=11)
    ax.set_ylabel("Concentración Equilibrio (mg/L)", fontsize=11)
    ax.set_title("La Luna – Dispersión 1:1\nInicial vs. Equilibrio Agua-Roca", fontsize=11)

    legend_els = [
        mpatches.Patch(facecolor="#2ca02c", label="Enriquecimiento (disolución de roca)"),
        mpatches.Patch(facecolor="#d62728", label="Empobrecimiento (precipitación)"),
        plt.Line2D([0], [0], ls="--", color="k", label="Línea 1:1"),
    ]
    ax.legend(handles=legend_els, fontsize=8.5, loc="upper left", framealpha=0.9)

    # ── Panel derecho: transferencia de masa mineral ──────────────────────────
    ax2 = axes[1]
    phases = list(PHASES_DELTA.keys())
    deltas = list(PHASES_DELTA.values())
    colors_bar = ["#d62728" if d < 0 else "#2ca02c" for d in deltas]
    bars = ax2.barh(phases, [d * 1e3 for d in deltas], color=colors_bar,
                    alpha=0.85, edgecolor="white")
    ax2.axvline(0, color="black", linewidth=1.1, alpha=0.7)
    ax2.set_xlabel("Δ Moles × 10⁻³ (precipitación +, disolución −)", fontsize=9)
    ax2.set_title("Transferencia de Masa\nLa Luna (PHREEQC)", fontsize=11)

    for bar, val in zip(bars, deltas):
        w = bar.get_width()
        offset = 0.03 if w >= 0 else -0.03
        ax2.text(
            w + offset * max(abs(v) * 1e3 for v in deltas),
            bar.get_y() + bar.get_height() / 2,
            f"{val*1e3:+.2f}",
            va="center",
            ha="left" if w >= 0 else "right",
            fontsize=8.5,
        )

    ax2.invert_yaxis()
    ax2.set_xlim(-3.5, 3.5)

    fig.tight_layout(pad=2.0)
    path = OUT_DIR / "fig2_scatter_1to1.png"
    fig.savefig(path, **SAVEFIG_KW)
    print(f"  ✓ {path}")
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════════
# FIGURA 3 – SI CALCITA (barras agrupadas)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_si_calcite() -> None:
    """
    Barras agrupadas que comparan el SI de la Calcita en el Escenario Base
    (agua cruda) vs. el Escenario Equilibrado para las cuatro formaciones.

    Demuestra cómo el equilibrio termodinámico lleva el sistema de
    sobresaturación variable a SI ≈ 0.
    """
    fms = ["La Luna", "Mugrosa", "Rosablanca", "Tablazo"]
    si_ini = [SI_CALCITE[f]["inicial"]    for f in fms]
    si_eq  = [SI_CALCITE[f]["equilibrio"] for f in fms]

    x = np.arange(len(fms))
    w = 0.36

    fig, ax = plt.subplots(figsize=(8.5, 5.2))

    bars_ini = ax.bar(x - w / 2, si_ini, w,
                      label="Agua Cruda (inicial)",
                      color="#4C72B0", alpha=0.88, edgecolor="white", linewidth=0.8)
    bars_eq  = ax.bar(x + w / 2, si_eq, w,
                      label="Agua Equilibrada (PHREEQC target = 0)",
                      color="#55A868", alpha=0.88, edgecolor="white", linewidth=0.8)

    # Etiquetas sobre barras iniciales
    for bar, val in zip(bars_ini, si_ini):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            val + 0.04,
            f"{val:.2f}",
            ha="center", va="bottom", fontsize=10, color="#4C72B0", fontweight="bold",
        )

    # Etiquetas sobre barras de equilibrio
    for bar in bars_eq:
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            0.04,
            "0.00",
            ha="center", va="bottom", fontsize=10, color="#2d7a4f", fontweight="bold",
        )

    # Línea de equilibrio
    ax.axhline(0.0, color="crimson", linewidth=1.6, linestyle="--",
               alpha=0.7, label="SI = 0 (equilibrio termodinámico)", zorder=2)

    # Región de subsaturación
    ax.axhspan(-0.5, 0.0, alpha=0.04, color="red")
    ax.axhspan(0.0, 0.2, alpha=0.04, color="green")

    # Anotaciones de zonas
    ax.text(3.7, -0.18, "Subsaturado\n(disolución)", ha="right", fontsize=8,
            color="tomato", style="italic")
    ax.text(3.7,  0.10, "Sobresaturado\n(precipitación)", ha="right", fontsize=8,
            color="seagreen", style="italic")

    ax.set_xticks(x)
    ax.set_xticklabels(fms, fontsize=12)
    ax.set_ylabel("Índice de Saturación – Calcita (log IAP/K)", fontsize=11)
    ax.set_title(
        "Índice de Saturación de Calcita\n"
        "Escenario Base vs. Equilibrio Agua-Roca (PHREEQC)",
        fontsize=12,
        pad=10,
    )
    ax.set_ylim(-0.45, 1.65)
    ax.legend(fontsize=9, loc="upper right", framealpha=0.9)

    ax.annotate(
        "† Equilibrio confirmado en La Luna por output PHREEQC\n"
        "  (Phase assemblage SI = 0.00). Para Mugrosa, Rosablanca\n"
        "  y Tablazo: SI = 0.00 por diseño del modelo.",
        xy=(0.01, 0.02),
        xycoords="axes fraction",
        fontsize=7.8,
        color="dimgray",
        style="italic",
        va="bottom",
    )

    fig.tight_layout()
    path = OUT_DIR / "fig3_si_calcite.png"
    fig.savefig(path, **SAVEFIG_KW)
    print(f"  ✓ {path}")
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print(f"\nGenerando figuras en: {OUT_DIR.resolve()}\n")
    plot_schoeller()
    plot_scatter_1to1()
    plot_si_calcite()
    print(f"\n3 figuras guardadas exitosamente.")
