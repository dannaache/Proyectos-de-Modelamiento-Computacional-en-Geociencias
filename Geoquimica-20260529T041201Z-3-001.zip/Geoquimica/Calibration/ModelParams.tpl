ptf @
@porosity@
@Calcite@
@Dolomite@
@Quartz@
@Kaolinite@
@Illite@
