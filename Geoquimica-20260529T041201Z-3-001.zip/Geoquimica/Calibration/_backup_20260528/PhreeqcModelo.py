import pandas as pd
import subprocess
import math

df = pd.read_csv("ModelParams.txt", sep = '/t', header = 3, names = ['Parameter'], engine = 'python')

Parameters = []
for row in df.iterrows():
    Parameters.append(row[1]["Parameter"][0:7])

x = Parameters
DictMinPerc = {'porosity' : x[0], #average formation porosity 
               'Calcite'  : x[1], #Calcite average percentage
               'Dolomite' : x[2], #Dolomite average percentage
               'Quartz'   : x[3], #Quartz average percetage
               'Kaolinite': x[4], #Kaolinite average percetage
               'Illite'   : x[5]  #Illite average percetage
}
DictMinPerc = {k: float(v) for k, v in DictMinPerc.items()}

mineral_props = {
    'Calcite':   {'rho': 2.71, 'mw': 100.087},
    'Dolomite':  {'rho': 2.84, 'mw': 184.40},
    'Quartz':    {'rho': 2.65, 'mw': 60.08},
    'Kaolinite': {'rho': 2.60, 'mw': 258.16},
    'Illite':    {'rho': 2.75, 'mw': 389.34} 
}

V_total_cm3 = 1000.0
porosity = DictMinPerc['porosity']
V_rock_cm3 = V_total_cm3 * ( 1 - porosity )

mols_mineral = {}

for mineral, props in mineral_props.items():
    if mineral in DictMinPerc:
        fraction = DictMinPerc[mineral]

        V_min_cm3 = V_rock_cm3 * fraction
        mass_g = V_min_cm3 * props['rho']
        mols = mass_g / props['mw']

        mols_mineral[mineral] = mols

with open("FmSolution.pqi", 'r') as f:
    lines = f.readlines()

with open("FmSolution.pqi", 'w') as f:
    for line in lines:
        clean_line = line.strip()
        parts = clean_line.split()

        if len(parts) >= 3 and parts[0] in mols_mineral:
            mineral = parts[0]
            saturation_index = parts[1]
            new_mols_value = mols_mineral[mineral]

            new_line = f"   {mineral:<18} {saturation_index:<7} {new_mols_value:.5f}\n"
            f.write(new_line)
        else:
            f.write(line)

subprocess.run("phreeqc.exe FmSolution.pqi ../phreeqc.dat", shell = True, check = True)

with open('CalFmSolution.txt'. 'r') as f:
          lines = [lines.split()[1:] for line in f.readlines()[1:] if line.strip()]

obs = [float(x) for x in lines[0]]
sim = [float(x) for x in lines[1]]

epsilon = 1e-6
rmse = math.sqrt(sum(((s - o) / (o + epsilon)) ** 2 for o, s in zip(obs, sim)) / len(obs))
