ptf @
# CusianaParams.tpl - Archivo Template para Ostrich
# Este archivo generará un archivo .txt con solo los valores numéricos paraPython
# Coincide con las variables definidas en el script Python

porosity   #average formation porosity 
Calcite    #Calcite average percentage
Dolomite   #Dolomite average percentage
Quartz     #Quartz average percetage
Kaolinite  #Kaolinite average percetage
Illite     #Illite average percetage
