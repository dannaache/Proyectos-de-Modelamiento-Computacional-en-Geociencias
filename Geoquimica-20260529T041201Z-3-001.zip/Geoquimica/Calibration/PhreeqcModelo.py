import math
import subprocess

# ═══════════════════════════════════════════════════════════════════════════════
# STAGE: solo mineralogía (6 parámetros)
# La variación de química de solución (10 params) está desactivada.
# Para activarla: descomentar secciones marcadas con [SOL-OFF]
# ═══════════════════════════════════════════════════════════════════════════════

# ── 1. Leer parámetros desde ModelParams.txt (escrito por Ostrich) ────────────
# Formato: un valor numérico por línea, sin cabeceras ni etiquetas.
# Ostrich llena este archivo desde ModelParams.tpl antes de llamar al modelo.
#   Línea 0 → porosity
#   Línea 1 → Calcite
#   Línea 2 → Dolomite
#   Línea 3 → Quartz
#   Línea 4 → Kaolinite
#   Línea 5 → Illite
# --- [SOL-OFF] líneas 6-15: Na Mg Ca K Cl S6 C4 Si Al Fe (desactivadas) ---
with open("ModelParams.txt") as f: # Lee el archivo generado por Ostrich con los parámetros a calibrar
    params = [line.strip().replace('@', '').strip() for line in f # Lee cada línea, elimina '@' y espacios, y filtra líneas vacías o comentarios
              if line.strip() and not line.strip().startswith('ptf') and not line.strip().startswith('#')]

MIN_KEYS = ['porosity', 'Calcite', 'Dolomite', 'Quartz', 'Kaolinite', 'Illite'] # Crea un diccionario para los parámetros de mineralogía
DictMinPerc = {k: float(params[i]) for i, k in enumerate(MIN_KEYS)}

# --- Química de solución [SOL-OFF] ---
# Descomenta este bloque cuando quieras activar la variación de composición:
#
# SOL_PHREEQC = ['Na', 'Mg', 'Ca', 'K', 'Cl', 'S(6)', 'Alkalinity', 'Si', 'Al', 'Fe']
# DictSolChem = {phq: float(params[6 + i]) for i, phq in enumerate(SOL_PHREEQC)}

# ── 2. Calcular moles de minerales ────────────────────────────────────────────
mineral_props = {
    'Calcite':   {'rho': 2.71, 'mw': 100.087},
    'Dolomite':  {'rho': 2.84, 'mw': 184.40},
    'Quartz':    {'rho': 2.65, 'mw': 60.08},
    'Kaolinite': {'rho': 2.60, 'mw': 258.16},
    'Illite':    {'rho': 2.75, 'mw': 389.34},
}

V_total_cm3 = 1000.0
V_rock_cm3 = V_total_cm3 * (1.0 - DictMinPerc['porosity'])

mols_mineral = {
    mineral: (V_rock_cm3 * DictMinPerc[mineral]) / props['mw']
    for mineral, props in mineral_props.items()
}

# ── 3. Actualizar FmSolution.pqi ──────────────────────────────────────────────
# Activo:     reemplaza moles en EQUILIBRIUM_PHASES
# Desactivado: reemplaza concentraciones en SOLUTION [SOL-OFF]
# Lee el archivo línea por línea.
with open("FmSolution.pqi", 'r') as f:
    pqi_lines = f.readlines()

with open("FmSolution.pqi", 'w') as f:
    for line in pqi_lines: #recorre linea por linea
        parts = line.strip().split() # Separa palabras

        # Ignora líneas vacías o sin palabras
        if not parts: 
            f.write(line)
            continue

        # Obtiene la primera palabra para identificar la sección
        kw = parts[0]

        if kw == '-water':
            f.write(f"    -water    {DictMinPerc['porosity']:.5f}\n")

        # --- EQUILIBRIUM_PHASES: actualiza moles (columna 3) ---
        # Si la línea corresponde a un mineral en EQUILIBRIUM_PHASES, actualiza su cantidad de moles.
        elif kw in mols_mineral and len(parts) >= 3:
            si = parts[1]
            f.write(f"    {kw:<18} {si:<7} {mols_mineral[kw]:.5f}\n")

        # --- SOLUTION: iones [SOL-OFF] (comentado) ---
        # elif kw == 'Alkalinity' and kw in DictSolChem:
        #     suffix = ' '.join(parts[2:]) if len(parts) > 2 else 'as HCO3'
        #     f.write(f"    Alkalinity      {DictSolChem['Alkalinity']:.4f} {suffix}\n")
        # elif kw in DictSolChem:
        #     suffix = ('  ' + ' '.join(parts[2:])) if len(parts) > 2 else ''
        #     f.write(f"    {kw:<16} {DictSolChem[kw]:.4f}{suffix}\n")

        else:
            f.write(line)

# ── 4. Correr PHREEQC ─────────────────────────────────────────────────────────
subprocess.run(
    "phreeqc FmSolution.pqi FmSolution.pqi.out ../phreeqc.dat",
    shell=True, check=True
)

# ── 5. Leer FmSolution.txt (SELECTED_OUTPUT) ─────────────────────────────────
# Columnas en orden: soln pH Alk Na Mg Ca K Cl S(6) C(4) Si Al Fe
# Fila 0 (header descartado por readlines()[1:])
# data[0] = solución inicial  → observaciones
# data[1] = solución equilibrada → simulado
# La columna 0 ('soln') se descarta con [1:]
with open('FmSolution.txt', 'r') as f:
    data = [line.split()[1:] for line in f.readlines()[1:] if line.strip()]

obs = [float(x) for x in data[0]]   # inicial    → "observaciones"
sim = [float(x) for x in data[1]]   # equilibrio → simulado

# ── 6. NRMSE (normalizado) → Ostrich minimiza hacia 0 ────────────────────────
epsilon = 1e-6
rmse = math.sqrt(
    sum(((s - o) / (o + epsilon)) ** 2 for o, s in zip(obs, sim)) / len(obs)
)


with open("ostOutput.txt", "w") as f:
    f.write(f"{rmse:.10f}\n")