@echo off
python PhreeqcModelo.py
